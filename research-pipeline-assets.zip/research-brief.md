# Research workflow slide: tools and skills consult

Initial review 2026-10-30; Recommendation and Distribution addendum checked 2026-11-01. Read-only research: nothing installed, cloned, or signed up for, and nobody contacted. Repository facts (license, last push, latest release) come from the GitHub API on the date stated. "Claim" means what the source says about itself. "Assessment" is my view.

The Herdr pane displayed Claude Opus 5.5 (`claude-opus-5-5`). Research sub-agents on Sonnet gathered the first pass. I re-checked license, release, and URL details against GitHub and the live pages. I could not independently confirm the `--model` flag.

## 1. Recommendation by stage

| Stage | Already on slide (carries over) | Fill the gap with | Why |
|---|---|---|---|
| Question | Obra Superpowers (`brainstorming`, `writing-plans`) | Heilmeier Catechism as the question checklist; optional pre-registration (OSF or AsPredicted) | Superpowers gives the process discipline. Heilmeier adds a short, research-specific test: what, why now, who cares, how will we know. |
| Data | Internal warehouse | Internal warehouse access and governance skills still need discovery from your internal documentation | Public tools do not replace the internal warehouse or its access rules. |
| Analysis | Meta Analytics Agent (internal) | Quarto (or Jupyter with pinned environments) for reproducibility. Superpowers `verification-before-completion` as the "show the output" habit | Analytics Agent is internal only (see §4). Quarto links analysis code to the write-up. |
| Write-up | Humanizer, Obra Superpowers | XX = a citation check: `grounded` (skill, claims ledger + judge) or RefChecker (CLI/web), plus the Crossref Retraction Watch data | Humanizer changes style, not facts. Something has to check that references exist and are not retracted. |
| Recommendation | No tool selected | A research synthesis or policy-brief skill to state a preferred option, alternatives, evidence, uncertainty, and trade-offs | Keep a person accountable for the recommendation. Distribution follows as a separate stage. |
| Distribution | No tool selected | A dissemination plan covering audience, message, format, channel, timing, and feedback | Share the findings; stop before implementation. |

Ribbon (Cheaper draft → Frontier challenge → Human judgment): keep it. The evidence is consistent with it but does not prove this exact pattern (§3). "Sol 6.1 · Max" stays an example reviewer, with no ranking claim.

## 2. Candidates in detail

Each row lists stage, type, purpose (claim), license, requirements, maintenance evidence, network/access needs, and my assessment.

### Agent skills (SKILL.md)

| Name and link | Stage | Type | Claim | License | Requirements / network | Maintenance seen | Assessment |
|---|---|---|---|---|---|---|---|
| [Agent Skills spec](https://agentskills.io/specification) ([repo](https://github.com/agentskills/agentskills)) | All | Spec | "A lightweight, open format for extending AI agent capabilities"; originally developed by Anthropic, released as an open standard | Apache-2.0 | None | Repo pushed 2026-08-09; no releases | Defines the format and says nothing about quality. |
| [Anthropic Agent Skills docs](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) | All | Docs | Skills package instructions, metadata and optional scripts | n/a | Says to use skills "only from trusted sources" and audit bundled scripts. API skills have no network; Claude Code skills have full network | Live page | Cite this for the safety line: installing a skill means installing software. |
| [anthropics/skills](https://github.com/anthropics/skills) | Write-up, Data | Collection | "Public repository for Agent Skills" | Per skill. docx/pdf/pptx/xlsx are proprietary (source-available); skill-creator is Apache-2.0 | Python and document tooling | Pushed 2026-10-28; no releases | Has no research skill. Useful for producing files. |
| [obra/superpowers](https://github.com/obra/superpowers) ([brainstorming](https://github.com/obra/superpowers/blob/main/skills/brainstorming/SKILL.md), [writing-plans](https://github.com/obra/superpowers/blob/main/skills/writing-plans/SKILL.md), [verification-before-completion](https://github.com/obra/superpowers/blob/main/skills/verification-before-completion/SKILL.md)) | Question, Analysis, Write-up | Collection / plugin | Software-development method; brainstorming covers "planning anything new, in software or out of it" | MIT | Skills host. **Network:** the brainstorming visual companion loads a logo from the maintainer's site by default and sends the Superpowers version; turn this off with `SUPERPOWERS_DISABLE_TELEMETRY` (README) | v7.0.1 on 2026-10-21; pushed 2026-10-29; large contributor base | Built for software work. Present it as adapted for research, not built for it. |
| [blader/humanizer](https://github.com/blader/humanizer) | Write-up | Standalone skill | "Rewrite AI-sounding text so it reads like the writer without changing what it says" | MIT | None | v3.1.0 on 2026-09-28; pushed 2026-10-28 | Edits style only. It does not check facts or citations. |
| [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | All, mainly Data / Analysis | Collection (177 skills) | "Scientific and research skills for AI agents"; 100+ databases | MIT | Python packages per skill; some skills need API keys or licensed databases; many call outside services | v2.72.0 on 2026-10-01; 30 releases; CI for skill tests, spec validation and security scans | Best maintenance evidence found. Leans toward life sciences. Pick individual skills and check each one's keys. |
| [jostelzer/grounded](https://github.com/jostelzer/grounded) | Write-up, Data | Skill + plugin | The project generates literature reviews from live searches and verified records. A separate judge compares assertions with sources. The ledger lists a source for each claim and labels unresolved references `NOT FOUND`. | MIT | Python 3, WeasyPrint. Calls OpenAlex, NCBI, Crossref, EBI; no keys stated | v0.5.6 on 2026-09-07; tests and evals; one maintainer; README says interfaces may change | Closest match for XX. Pre-1.0, so pilot it first. |
| [WenyuChiou/ai-research-skills](https://github.com/WenyuChiou/ai-research-skills) | All five | Catalog + plugins | "17 portable skills, 8 lifecycle stages"; explicit human gates | MIT | The executable runtime is a separate component; Zotero integration | v1.7.18 on 2026-10-29; tests; one maintainer; created 2026-04 | Closest whole-lifecycle framing. Depends on a runtime outside the repo. |
| [research-paper-lifecycle-skills](https://github.com/ShaishavMaisuria/research-paper-lifecycle-skills) | Data → Decision (venue) | Collection (42) | "Whole research-paper lifecycle … you stay the author" | Apache-2.0 | Live web lookups | v1.0.0 on 2026-06-27; pushed 2026-10-24; single author | Aimed at academic papers. I did not see tests. |
| [Socialpranker/deepdive](https://github.com/Socialpranker/deepdive) | Question, Data, Decision | Skill | 12-phase research pipeline that ends in a decision log | MIT | Python; optional APIs | No releases; pushed 2026-10-25; tests and evals present | I found one skill that ends in a decision record. Its evidence is self-reported. |
| [claude-deep-research-skill](https://github.com/199-biotechnologies/claude-deep-research-skill) | Data | Skill | 8-phase deep research with source credibility scoring | **No license** | Python | Pushed 2026-04-11 | Without a license, reuse rights are unclear. Do not name it on the slide. |

Other skills seen but weaker or narrower: AlterLab-Academic-Skills (MIT, says it has evals for all 242 skills; self-reported), KalarisLabs/research-agent-skills (mixed license signals), DeepPaperNote (single-paper reading, MIT), claude-skills-journalism (MIT, journalism scope), meta-analysis-skill (license unclear). Directories: [VoltAgent/awesome-agent-skills](https://github.com/VoltAgent/awesome-agent-skills), [awesome-research-skills](https://github.com/neverbiasu/awesome-research-skills). The lists themselves are unvetted.

### Data: retrieval, provenance, quality

| Name and link | Type | Claim | License | Needs | Maintenance | Assessment |
|---|---|---|---|---|---|---|
| [OpenAlex](https://openalex.org/) | Open index + API | Data is CC0; works without an account | Data CC0 | HTTP. A free key raises limits; heavy use is pay-as-you-go | Live service | Best open default for finding papers. |
| [Crossref REST API](https://www.crossref.org/documentation/retrieve-metadata/rest-api/) | API | Free scholarly metadata; open API access | Metadata mostly not copyrighted; site CC BY 4.0 | Users can query the API without an account; `mailto` enters the polite pool | Live | The authority for DOI metadata. |
| [Zotero](https://www.zotero.org/) | Desktop app + sync | "Collect, organize, annotate, cite, and share research" | AGPL-3.0 (COPYING) | Desktop app; account only for sync and the web API | Repo pushed 2026-10-29 | Standard reference library. Only community MCP servers exist. |
| [Zenodo](https://about.zenodo.org/) | Repository | Data and software from any discipline; DOIs through DataCite | Metadata CC0; uploader chooses the content license | Free account to deposit | Live | Easiest way to get a citable snapshot. |
| [RO-Crate](https://www.researchobject.org/ro-crate/) | Spec | "Lightweight approach to packaging research data with their metadata" | Apache-2.0 | None (JSON-LD) | 1.3.0 on 2026-06-22 | One folder holding data, code and metadata. |
| [Frictionless Data Package](https://datapackage.org/) / [frictionless-py](https://github.com/frictionlessdata/frictionless-py) | Spec + Python tool | Describe and validate tabular data | frictionless-py is MIT; spec license not stated | Python | v5.21.0 on 2026-10-15 | Simplest provenance plus validation for CSVs. |
| [W3C PROV](https://www.w3.org/TR/prov-overview/) | Spec (2013) | Data model for provenance | W3C document license | None | Stable since 2013 | A reference vocabulary. Rarely written by hand. |
| [FAIR principles](https://www.gofair.foundation/fair-principles) | Framework | Findable, Accessible, Interoperable, Reusable | Site CC BY 4.0 | None | 2016 paper | It offers a checklist for describing data. |
| [Datasheets for Datasets](https://arxiv.org/abs/1803.09010) | Method (paper) | A standard question list for each dataset | arXiv | None | v8, 2021 | Good for "what is in this data?" |
| [pandera](https://github.com/unionai-oss/pandera) | Python library | "Statistical data testing library" | MIT | Python | v0.35.0 on 2026-10-25 | Lightest quality check. |
| [Great Expectations](https://github.com/great-expectations/great_expectations) | Python framework | "Always know what to expect from your data" | Apache-2.0 | Python; more setup | 1.24.1 on 2026-10-22 | Heavier and well known. |

I dropped deepchecks because it appears stale and its license is unclear. Soda Core also has an unclear license. Harvard Dataverse pages did not load during this check.

### Analysis: reproducibility

| Name and link | License | Maintenance | Assessment |
|---|---|---|---|
| [Quarto](https://quarto.org/) | MIT (COPYING.md, Posit) | v1.10.20 on 2026-10-30 | Connects code, results and citations; also serves Write-up. |
| [DVC](https://github.com/iterative/dvc) | Apache-2.0 | 3.67.1 on 2026-03-31; repo active | Versions data next to git. |
| [Snakemake](https://github.com/snakemake/snakemake) | MIT | v9.27.1 on 2026-10-21 | For multi-step pipelines. |
| [Jupyter](https://jupyter.org/) | BSD-3-Clause | v7.6.4 on 2026-10-30 | Common, but not reproducible without pinned environments. |
| [The Turing Way](https://book.the-turing-way.org/) | CC BY 4.0 | No version shown | A handbook to cite as the reproducibility reference. |

### Question, Write-up and Decision methods

| Name and link | Stage | Type | Claim / content | License / terms | Assessment |
|---|---|---|---|---|---|
| [Heilmeier Catechism](https://www.darpa.mil/about/heilmeier-catechism) | Question | Method | Eight DARPA questions, starting with "What are you trying to do?" | Not stated | Best single question-framing checklist. |
| [COS pre-registration](https://www.cos.io/initiatives/prereg), [AsPredicted](https://aspredicted.org/) | Question | Service | Register the plan before seeing the data | Account required | Strong for confirmatory studies. A dated question file in git does much of the same job. |
| [Citation Style Language](https://citationstyles.org/) | Write-up | Standard | 10,000+ free styles | Styles CC BY-SA 3.0 | Used underneath Zotero, Pandoc and Quarto. |
| [Better BibTeX](https://github.com/retorquere/zotero-better-bibtex) | Write-up | Zotero plugin | Stable citation keys | MIT | Stable keys stop an LLM from inventing new ones. |
| [RefChecker](https://github.com/markrussinovich/refchecker) | Write-up | CLI / web | Validates references against Semantic Scholar, OpenAlex, Crossref, DBLP | MIT; no key for basic use, optional LLM keys | Plain alternative to `grounded`. |
| [Crossref Retraction Watch data](https://www.crossref.org/documentation/retrieve-metadata/retraction-watch/) | Write-up | Open data + API | Retraction notices, updated every working day | Data license not stated on the page | Free retraction screen. Check the license before redistributing. |
| [EQUATOR Network](https://www.equator-network.org/) | Write-up | Reporting guidelines | CONSORT, PRISMA and others | Terms page | Health research only. |
| [MADR](https://adr.github.io/madr/) | Decision | Template | Markdown decision records: options, drivers, consequences | MIT or CC0 | Practical record of a decision. v4.0.0 (2024) is stable. |
| [Pre-mortem (Klein, HBR 2007)](https://hbr.org/2007/09/performing-a-project-premortem) | Decision | Method | Assume the project has failed, then list the reasons | HBR copyright | Cheap, and fits the challenge step. |
| [UK MOD Red Teaming Handbook](https://www.gov.uk/government/publications/a-guide-to-red-teaming) | Decision / challenge | Guide | Structured challenge techniques | OGL v3 | Primary, open source for devil's-advocate methods. |
| [NIST AI RMF](https://www.nist.gov/itl/ai-risk-management-framework) | Decision (context) | Framework | Voluntary AI risk guidance | US government | Background only. It does not prescribe this ribbon. |
| GRADE Evidence-to-Decision (Alonso-Coello et al., BMJ 2016;353:i2016) | Decision | Framework | Separates the evidence from the judgment | Not checked | **Unverified:** the BMJ page returned 403. Verify before citing. |

Not verified, so left out: PICO original source, FINER, Question Formulation Technique, decision journals, PR-FAQ, "decision hygiene" (book not opened).

## 3. Evidence on the ribbon

- [Zheng et al. 2023](https://arxiv.org/abs/2306.05685) report that strong LLM judges agree with humans over 80% of the time, close to the human-human rate. Their tests also found position, verbosity, and self-enhancement biases.
- Panickssery et al. 2024 ([arXiv 2404.13076](https://arxiv.org/abs/2404.13076), not opened directly): LLM evaluators recognize and favor their own generations. So the challenger should be a different model from the drafter, as the ribbon already suggests.
- Citation fabrication: Walters and Wilder 2023 (Sci Rep 13, doi 10.1038/s41598-023-41032-5; numbers from summaries) report 55% fabricated citations for GPT-3.5 and 18% for GPT-4. [Naser 2026](https://arxiv.org/abs/2603.03299) (single-author preprint) reports 11.4% to 56.8% across ten models. Run an existence check before a human reads the draft.
- The cited papers do not test the exact cheap-draft, frontier-challenge, human pattern. Say the evidence is "consistent with" the ribbon.

## 4. Meta Analytics Agent

I checked official Meta sources but could not verify a public page or installation path for Analytics Agent. The pack marks it **internal only**; its logo status is unknown. A Meta analytics team Medium post ("Inside Meta's Home Grown AI Analytics Agent") is widely cited, but it returned HTTP 403 to us, so I have not verified it. A secondary summary in [Data Engineering Weekly #264](https://www.dataengineeringweekly.com/p/data-engineering-weekly-264) reports "cookbooks, recipes, and ingredients" and 77% weekly adoption. **Please send the internal link you want viewers to use.** I'll add a QR only once that exact URL is confirmed.

## 5. Gaps and limits

- **Skill files do not guarantee quality.** A SKILL.md is instructions plus optional scripts. Tests, evals and CI badges show process, not correct research output, and most "eval coverage" claims here are self-reported. Read the body and scripts of any third-party skill before installing it.
- **No skill handles Decision well.** Only deepdive ends in a decision log. Decision support here means templates and methods.
- **Data is domain-specific.** The internal warehouse that Analytics Agent uses is not covered by any public tool.
- **Licenses:** anthropics/skills document skills are proprietary. claude-deep-research-skill has no license. The Retraction Watch data license is not stated on the docs page.
- **Network:** most research skills call outside APIs (OpenAlex, Crossref, NCBI, web search). Some need keys or paid tiers. Superpowers has an opt-out telemetry ping.
- **Young projects:** grounded, WenyuChiou, deepdive and research-paper-lifecycle-skills are all under eight months old, and most have a one maintainer.

## 6. What needs human judgment

1. Which person or group is accountable for the recommendation, and which audience needs it? These answers set the recommendation format and distribution plan.
2. Whether XX should be a skill (grounded) or a plain tool (RefChecker or Zotero + Retraction Watch). This trades automation against auditability.
3. Which internal documentation describes the approved warehouse access and governance skills?
4. Whether to name third-party skills on a slide at all, given the trust and licensing points above.
5. The Write-up QR cannot point to Humanizer, Superpowers, and XX at once. Choose one destination or provide a real curated landing page; I have not created one.
6. Whether "Sol 6.1 · Max" stays as an example. Keep the no-ranking wording.

## 7. Asset pack

`research-pipeline-assets.zip` contains the asset files and `manifest.csv`; this brief travels beside them in the same ZIP. It contains two unmodified official Obra Superpowers marks and 15 generic outline icons in #302D29 and #C65336 (SVG and transparent PNG). Each of the 11 QR destinations returned HTTP 200. PNG and SVG versions decoded to the exact URL and have a white four-module quiet zone. No QR points to Meta Analytics Agent or a combined Write-up page. Candidate-specific QR files are not assigned to undecided slots.

## 7. Recommendation and Distribution addendum (2026-11-01)

The slide now ends with **Recommendation → Distribution**. Implementation is outside this research workflow.

### Recommendation candidates

- [Anthropic `research-synthesis`](https://github.com/anthropics/knowledge-work-plugins/blob/main/design/skills/research-synthesis/SKILL.md) accepts interview transcripts, surveys, usability notes, feedback, and related user-research data. Its output includes themes, supporting evidence, implications, recommendations, further questions, and methodology notes. It is the clearest direct skill lead found, with a product/user-research focus.
- [SkillMedev `policy-brief`](https://github.com/SkillMedev/academic-researcher/blob/main/skills/policy-brief/SKILL.md) structures options and evidence into recommendations. This is a small, recently created repository. Review it before use, and remove its implementation-planning section from this workflow.
- [K-Dense Scientific Critical Thinking](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/scientific-critical-thinking/SKILL.md) can challenge a proposed recommendation by checking assumptions and alternatives. It does not assign decision authority.

### Distribution resources

- [AHRQ Dissemination Planning Tool](https://www.ahrq.gov/patient-safety/reports/advances/planning.html) asks researchers to specify the findings and products, end users, partners, communication approach, evaluation, and work plan. Its context is health research, while the planning questions are broadly useful.
- [NHMRC Dissemination and Communication](https://www.nhmrc.gov.au/guidelinesforguidelines/implement/dissemination-and-communication) calls for a planned process based on audience, message, and communication strategies. It also covers audience preferences, channels, feedback, and refinement. The broader NHMRC site includes implementation guidance; that material is excluded here.
- [PRB Research Translation Toolkit](https://www.prb.org/resource/research-translation-toolkit/) offers audience analysis and formats such as fact sheets and policy briefs. Use the communication resources; leave action planning outside this workflow.

No mature, general-purpose agent skill for research distribution was verified. The AHRQ, NHMRC, and PRB items are planning guides. Distribution means preparing and sharing research findings with intended audiences. It ends before anyone puts recommendations into practice.

The internal warehouse is the Data stage. Its approved access path and skill must come from internal documentation. No public tool or QR is substituted for it.
