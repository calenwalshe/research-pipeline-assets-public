# Research pipeline slide assets

Updated 2026-11-01 for the Question -> Data -> Analysis -> Write-up -> Recommendation -> Distribution slide. Details for every visual file are in `manifest.csv`. The ZIP also includes a source-linked research brief and a skills landscape.

## Folders

- `official/`: Obra Superpowers marks, unmodified, from github.com/obra/superpowers/tree/main/assets (MIT repo). Keep the proportions and do not recolor.
- `icons/`: Generic outline icons (24-unit grid, 1.75 stroke, no fill) in `_ink` (#302D29) and `_terracotta` (#C65336), as SVG and transparent 512px PNG. They are CC0 and do not represent any product. The folder includes a stage icon for each workflow step.
- `qr/`: The package includes 8 QR destinations. Each has SVG and PNG codes, drawn in #302D29 on white, with a four-module quiet zone. On 2026-10-30, each linked URL returned HTTP 200 and decoded to the exact destination. Candidate files point to options not selected for the slide.

## Palette

| Use | Hex |
|---|---|
| Slide background | #F4F0E6 |
| Dark ink icons, QR modules | #302D29 |
| Accent icons | #C65336 |
| Muted text | #877E72 |

Icons are transparent. Place QR codes on a white tile to preserve contrast against the cream background.

## Not included

- Meta Analytics Agent: internal only. No public page verified, so there is no logo or QR. Send the internal link and a QR can be made and checked.
- The Write-up “XX” tool remains undecided. Recommendation and Distribution resources are candidates only. Candidate-specific QR files are not selected stage codes.
- The Write-up QR: one QR cannot point to several tools. That needs a real curated landing page, and none was invented.

## Research skill links

- `skills-landscape.md` summarizes skills and methods by stage and gives a proposed handoff structure. The Recommendation and Distribution entries are candidates, not selected tools.
- `skills-landscape.csv` provides resource links in a sortable table. Data is the internal warehouse; its access method still needs internal documentation. The specific internal destinations for Meta Analytics Agent and the Write-up QR are still missing.
- `candidates.md` lists candidate resources for undecided slots. None is selected.
- `missing-assets.md` records internal links and remaining QR, logo, and identity gaps. Implementation is outside this workflow.
