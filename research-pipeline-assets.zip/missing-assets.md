# Missing links and open choices

Updated 2026-11-01.

## Internal warehouse and Meta Analytics Agent

Data is the internal warehouse. The public pack cannot identify approved access skills, connectors, or governance steps without internal documentation. Meta Analytics Agent also has no verified public installation page. Provide the internal documentation URL that slide viewers are allowed to use. No outside product has been substituted.

No Meta logo or QR is included. Once the intended internal destination is supplied and confirmed, a QR can be generated and decoded against that exact URL.

## Write-up QR slot

Write-up currently names Humanizer, Obra Superpowers, and an undecided “XX” tool. The package includes separate QRs for verified public tools. One slide QR cannot point directly to several destinations. Provide a real curated landing page or choose one destination. No landing page URL was invented.

## Recommendation and Distribution

The resources in `candidates.md` and `skills-landscape.md` are suggestions only. No skill or guide has been selected for the slide. Distribution covers preparing and sharing findings with intended audiences. Implementation is outside the research workflow.

## Humanizer identity

The local Humanizer skill text matches `blader/humanizer`, including its metadata and wording. I used that project for the Humanizer assets and marked it as verified. Other projects also use the name “Humanizer”; if the slide refers to another one, replace the destination and QR.

## Logos

The Obra Superpowers repository includes an official PNG app icon. No matching SVG was found in its repository assets. The Humanizer repository has no official logo or icon. Use a generic icon from `icons/` for that label.
