# Candidate resources for undecided slide slots

Updated 2026-11-01. These are options for review. None is selected for the slide. RigorCheck is excluded.

## Data: internal warehouse

No public candidates are listed for this stage. Identify the approved warehouse access skill and documentation internally. Do not substitute an external dataset or connector.

## Write-up: XX

- [Grounded](https://github.com/jostelzer/grounded). research skill and CLI that builds a source-linked claim ledger and checks citations.
- [RefChecker](https://github.com/markrussinovich/refchecker). tool for checking bibliographic references against scholarly indexes.
- [K-Dense Citation Management](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/citation-management/SKILL.md). agent skill that checks citation metadata and formats reference entries.

Humanizer and Obra Superpowers are already shown in the Write-up stage. This slot could cover citation verification or source-to-claim checking.

## Recommendation

- [Anthropic Research Synthesis](https://github.com/anthropics/knowledge-work-plugins/blob/main/design/skills/research-synthesis/SKILL.md). Skill for user research that creates themes, implications, and prioritized recommendations from interviews, surveys, usability notes, and feedback. Adapt its product focus for other research domains.
- [Policy Brief](https://github.com/SkillMedev/academic-researcher/blob/main/skills/policy-brief/SKILL.md). Skill for comparing options and writing evidence-based recommendations. New, small project; review before use and remove the implementation-planning step.
- [Scientific Critical Thinking](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/scientific-critical-thinking/SKILL.md). Review aid for checking claims, assumptions, alternatives, and uncertainty before a human makes a recommendation.

These are candidates only. The recommendation should state the preferred option, alternatives, evidence, uncertainty, trade-offs, and what could change it. A named person or group remains accountable.

## Distribution

- [AHRQ Dissemination Planning Tool](https://www.ahrq.gov/patient-safety/reports/advances/planning.html). Practical planning template covering findings, end users, partners, communication, evaluation, and a work plan. Written for health research; the questions transfer.
- [NHMRC Dissemination and Communication](https://www.nhmrc.gov.au/guidelinesforguidelines/implement/dissemination-and-communication). Guidance on audience needs, key messages, channels, feedback, and refining communication. Health guideline context.
- [PRB Research Translation Toolkit](https://www.prb.org/resource/research-translation-toolkit/). Audience analysis and communication product ideas, including short briefs. Use the communication parts; its action-planning material extends beyond this workflow.

The AHRQ, NHMRC, and PRB items are communication planning guides. For this slide, Distribution means preparing and sharing findings with the intended audience. It ends before implementation.
