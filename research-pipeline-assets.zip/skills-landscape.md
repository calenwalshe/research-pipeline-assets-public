# Skills for a research workflow

Checked 2026-10-30. Every skill and method here is a candidate for review. None has been selected for the slide. The ZIP's `manifest.csv` still describes the local visual assets and verified QR codes. RigorCheck is outside this review.

## Landscape

Several large collections now publish `SKILL.md` playbooks for research. Their broadest coverage is scientific brainstorming, literature search, study design, data handling, statistics, visualization, writing, and peer review. Recommendation skills are emerging, while Distribution is better served by communication planning guides and templates.

A skill tells an agent when and how to do a task. It can also call scripts, APIs, databases, or paid services. A skill file is not evidence that the method is correct or that the skill works in your environment. Review its instructions, scripts, license, network calls, and domain fit before installing it.

## Shortlist by stage

| Stage | Skills | How they help | Fit and limits |
|---|---|---|---|
| Question | [Obra Superpowers brainstorming](https://github.com/obra/superpowers/blob/main/skills/brainstorming/SKILL.md); [Scientific Brainstorming](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/scientific-brainstorming/SKILL.md); [Research Design Helper](https://github.com/WenyuChiou/research-hub/blob/master/skills/research-design-helper/SKILL.md) | Turn a topic into a scoped, testable question; keep assumptions, alternatives, and decision owners visible. | Superpowers is general-purpose and needs adaptation for research. The scientific version calls for independent idea generation, evidence checks, and a human decision. Research Design Helper uses a guided five-part design brief. |
| Data | Internal warehouse | Use the organization's approved warehouse access, query, and data-governance skills. | Need the internal documentation and access model before naming tools or skills. Public data tools are not substitutes. |
| Analysis | [Experimental Design](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/experimental-design/SKILL.md); [Statistical Power](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/statistical-power/SKILL.md); [Statistical Analysis](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/statistical-analysis/SKILL.md); [Scientific Visualization](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/scientific-visualization/SKILL.md) | Plan the study before collection; choose sample size; analyze with assumptions and uncertainty visible; make figures that show the data fairly. | These solve different tasks. Experimental design and power belong before data collection. Statistical Analysis is for data already collected. They do not replace a qualified analyst or the Meta Analytics Agent's internal data access. |
| Write-up | [Scientific Writing](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/scientific-writing/SKILL.md); [Citation Management](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/citation-management/SKILL.md); [Peer Review](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/peer-review/SKILL.md); [Humanizer](https://github.com/blader/humanizer) | Keep claims connected to evidence; check citation metadata; review methods, statistics, figures, and limitations; edit style after the factual checks. | Humanizer changes prose style. It does not check whether claims or citations are true. Reporting checklists such as PRISMA or CONSORT apply only to their research types. |
| Recommendation | [Anthropic Research Synthesis](https://github.com/anthropics/knowledge-work-plugins/blob/main/design/skills/research-synthesis/SKILL.md); [Policy Brief](https://github.com/SkillMedev/academic-researcher/blob/main/skills/policy-brief/SKILL.md); [Scientific Critical Thinking](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/scientific-critical-thinking/SKILL.md) | Turn findings into options and a recommendation, with evidence, trade-offs, uncertainty, and questions still open. | Anthropic's skill is strongest for user research and product recommendations. The policy-brief skill is a young project and includes implementation planning; omit that part for this workflow. Critical Thinking checks a proposed recommendation. A person or group remains accountable. |
| Distribution | [AHRQ Dissemination Planning Tool](https://www.ahrq.gov/patient-safety/reports/advances/planning.html); [NHMRC Dissemination and Communication](https://www.nhmrc.gov.au/guidelinesforguidelines/implement/dissemination-and-communication); [PRB Research Translation Toolkit](https://www.prb.org/resource/research-translation-toolkit/) | Identify the audience, message, channel, partners, materials, timing, and how reach or feedback will be assessed. | AHRQ and NHMRC are health-sector sources, and their planning questions transfer. These guides cover sharing findings with an intended audience. Exclude implementation material. |

## Challenge and human judgment

For “Cheaper draft → Frontier challenge → Human judgment,” use K-Dense [Scientific Critical Thinking](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/scientific-critical-thinking/SKILL.md) and [Peer Review](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/skills/peer-review/SKILL.md) as reference playbooks. The challenge checks for counterevidence or missing sources. It considers alternative explanations and method problems, then records uncertainty. The decision owner records which criticisms they accept and why.

“Sol 6.1 · Max” is the example reviewer on the ribbon. No model ranking is claimed.

## Whole-workflow examples

- [Research Lab](https://github.com/pbi-agent/skills/blob/main/skills/research-lab/SKILL.md) describes a staged, evidence-based workflow that can cover framing, comparison, decision, implementation, and a final artifact across software, data, academic research, product, and policy work. It expects durable research notes and explicit handoffs.
- [Research Workflow Orchestrator](https://github.com/WenyuChiou/research-hub/blob/master/skills/research-workflow-orchestrator/SKILL.md) describes an eight-stage, human-in-the-loop workflow from orientation and scope through discovery, synthesis, design, execution, writing, and release. Its integrations and runtime need checking before adoption.
- [K-Dense Scientific Agent Skills](https://github.com/K-Dense-AI/scientific-agent-skills/blob/main/docs/skills.md) has focused skills across information retrieval, data management, study design, analysis, writing, citation work, and review. It is a large catalog; select individual skills and review their dependencies.
- [Awesome Research Skills](https://github.com/neverbiasu/awesome-research-skills) indexes 150 skills across ideation, literature, data, experiments, statistics, writing, and peer review. Its maintainer says entries are checked, with some manually audited. Its maintainer presents it as a curated directory. Review each skill for your own use.
- [Kalaris Research Agent Skills](https://github.com/KalarisLabs/research-agent-skills) describes a cross-disciplinary library for research from question formation through writing and peer review. Treat its coverage and test claims as project claims and inspect the specific skill you might use.
- [DeerFlow Systematic Literature Review](https://github.com/bytedance/deer-flow/blob/main/skills/public/systematic-literature-review/SKILL.md) is a more bounded example: it searches arXiv and synthesizes papers with citations. Its arXiv-only workflow sets a 50-paper limit. One extraction step requires subagents.

## What to build into a full pipeline skill

Use the six stages Question → Data → Analysis → Write-up → Recommendation → Distribution. Give each stage a handoff artifact so later work can be checked:

1. **Question:** one-sentence question, audience, decision owner, scope, assumptions, success criteria, and what evidence could change the plan.
2. **Data:** sources, permissions, metadata, provenance, collection or search record, inclusion rules, and quality checks.
3. **Analysis:** approved analysis plan, code or query, environment, data version, assumptions, outputs, uncertainty, and deviations.
4. **Write-up:** claim-to-source list, methods and limitations, verified references, required reporting checklist, and a challenge response log.
5. **Recommendation:** preferred option, alternatives, evidence for and against, trade-offs, uncertainty, conditions, and what new evidence could change the recommendation.
6. **Distribution:** audience, key message, format, channel, responsible person, timing, access needs, and a way to track audience response.

Add human gates for research ethics, privacy, safety, and restricted data where they apply. Keep them visible. Data is the internal warehouse. The access skill and workflow must come from internal documentation. Meta Analytics Agent also remains internal until you provide its destination. Write-up contains several tools. Its QR needs a chosen destination or a real curated page. Recommendation and Distribution resources here are candidates. Implementation is outside this research workflow.

## New leads for Recommendation and Distribution

- **Best direct skill lead:** Anthropic's `research-synthesis` skill turns user research into themes, implications, prioritized recommendations, and further-research questions. It is designed for product/user research; adapt it for other domains and retain its separation of observation and interpretation.
- **General recommendation format:** SkillMedev's `policy-brief` skill structures options and recommendations around a decision and evidence. It is a small, new project. Its final implementation-planning step should be removed here because implementation is outside the research pipeline.
- **Distribution:** No mature, general-purpose `SKILL.md` specifically for research distribution stood out. Use AHRQ's planning tool as a template for findings/products, end users, partners, communication, evaluation, and work plan. NHMRC adds audience needs, key messages, channels, feedback, and refinement. These sources include implementation content elsewhere; only the communication/dissemination planning applies here.
- **Slide label:** “Distribution” is clear. It means delivering findings in a usable form to the audiences that need them. It does not include putting recommendations into operation.

## Sources and checking limits

The linked repository files were opened during this review on 2026-10-30. The descriptions above summarize project claims. We did not run every skill. Check the method and environment fit before use. Repository catalogs can change, so review the specific skill, license, version, and dependencies before installation.
